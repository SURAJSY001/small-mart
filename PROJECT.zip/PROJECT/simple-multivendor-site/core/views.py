from django.shortcuts import render
from product.models import Product

# Create your views here.

def frontpage(request):
    newest_products = Product.objects.all()[0:8]
    context = {
        'newest_products': newest_products,
    }
    return render(request, 'core/frontpage.html', context)


def contactpage(request):
    return render(request, 'core/contact.html')



import csv
import matplotlib.pyplot as plt
from django.http import HttpResponse
import io
from django.shortcuts import render

import matplotlib
print(matplotlib.__version__)


import base64



import csv
import matplotlib.pyplot as plt
from django.http import HttpResponse
import io
from django.shortcuts import render
import base64

import matplotlib
print(matplotlib.__version__)




def product_bar_chart(request):
    product_count = {}
    with open('order_vendor.csv', 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file, fieldnames=['order_id', 'product_id', 'product_name', 'quantity', 'price', 'paid_amount'])
        next(csv_reader) # Skip first row
        for row in csv_reader:
            product_name = row['product_name']
            if product_name in product_count:
                product_count[product_name] += 1
            else:
                product_count[product_name] = 1

    # Generate bar graph
    plt.figure(figsize=(10,6))
    plt.bar(product_count.keys(), product_count.values(), width=0.4)
    plt.xticks(list(product_count.keys()), rotation='horizontal')

    # Save graph to image buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    plt.close()

    # Encode the image data as a base64 string
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # Pass the image base64 string to the template context
    context = {
        'image_base64': image_base64
    }

    return render(request, 'core/product_bar_chart.html', context)
