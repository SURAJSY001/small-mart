from cart.cart import Cart

from django.conf import settings
# for HTML Email
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string

from .models import Order, OrderItem

def checkout(request, first_name, last_name, email, address, zipcode, place, phone, amount):
    order = Order.objects.create(first_name=first_name, last_name=last_name, email=email, address=address, zipcode=zipcode, place=place, phone=phone, paid_amount=amount)

    for item in Cart(request):
        OrderItem.objects.create(order=order, product=item['product'], vendor=item['product'].vendor, price=item['product'].price, quantity=item['quantity'])
        order.vendors.add(item['product'].vendor)
        
    return order

import os
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from order.models import Order

def notify_vendor(order):
    from_email = settings.DEFAULT_EMAIL_FROM
    for vendor in order.vendors.all():
        to_email = vendor.created_by.email
        subject = 'New order'
        text_content = 'You have a new order!'
        csv_content = "Order ID, Product ID,Product Name, Quantity, Price,Paid amount\n"
        for item in order.items.all():
            product = Product.objects.get(id=item.product.id)
            csv_content += f"{order.id}, {item.product.id},{product.title}, {item.quantity}, {item.price}, {order.paid_amount} \n"
        # filename = f'order_{order.id}_vendor.csv'
        filename = f'order_vendor.csv'


        with open(filename, 'a') as f:
            f.write(csv_content)
        msg = EmailMultiAlternatives(subject, text_content, from_email, [to_email])
        msg.attach_file(filename)
        msg.send()


import os
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from order.models import Order
from product.models import Product

def notify_customer(order):
    from_email = settings.DEFAULT_EMAIL_FROM
    to_email = order.email
    subject = 'Order confirmation'
    text_content = 'Thank you for the order!'

    msg = EmailMultiAlternatives(subject, text_content, from_email, [to_email])

    # Get all the values and save them to a text file
    vendor_names = ', '.join([v.name for v in order.vendors.all()])
    values = f"Name: {order.first_name} {order.last_name}\nAddress: {order.phone}\nZip and place: {order.zipcode} {order.place}\nE-mail: {order.email}\nPhone: {order.address}\nPaid amount: {order.paid_amount}\nVendor: {vendor_names}\n\nProducts:\n"

    for item in order.items.all():
        product = Product.objects.get(id=item.product.id)
        product_name = product.title
        quantity = item.quantity
        price = item.price
        order_Number = item.order_id
        values += f"Product Name: {product_name}\n Quantity: {quantity}\n price: {price}\n order Number: {order_Number}\n"

    # Save the customer order details to a text file
    filename = f'order_customer.txt'
    with open(filename, 'w') as f:
        f.write(values)
    print(f'Customer order details saved to file {filename}')

    # Attach the text file to the email
    with open(filename, 'r') as f:
        file_content = f.read()
    msg.attach(filename, file_content)

    # # Add image attachment
    # image_path = '..\\simple-multivendor-site\\media\\qr.png'  # Replace with the actual path to your image file
    # msg.attach_file(image_path)

    # Send the email
    msg.send()
